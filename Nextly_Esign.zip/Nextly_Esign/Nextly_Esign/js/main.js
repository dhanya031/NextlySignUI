/* Slide */
var swiper = new Swiper(".login-slider", {
  spaceBetween: 30,
  centeredSlides: true,
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
});

/* Tooltip*/
var tooltipTriggerList = [].slice.call(
  document.querySelectorAll('[data-bs-toggle="tooltip"]')
);
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl);
});

/*Animatiom */
const cards = document.querySelectorAll('.card, table, section');
gsap.from(cards, {
  duration: 1,
  opacity: 0,
  y: 50,
  stagger: 0.2,
  ease: 'power2.out'
});


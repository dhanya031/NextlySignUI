const fileInput = document.getElementById('fileInput');
const fileNameInput = document.getElementById('fileName');
const dragFileInput = document.getElementById('dragFileInput');
const dragFileName = document.getElementById('dragFile');
const dragBox = document.getElementById('dragBox');
const dragFile = document.getElementById('dragFile');

fileInput.addEventListener('change', function(event) {
    const files = event.target.files;
    handleFileSelect(files);
});

dragBox.addEventListener('dragover', function(event) {
    event.preventDefault();
    dragBox.classList.add('drag-over');
});

dragBox.addEventListener('dragleave', function(event) {
    event.preventDefault();
    dragBox.classList.remove('drag-over');
});

dragBox.addEventListener('drop', function(event) {
    event.preventDefault();
    dragBox.classList.remove('drag-over');
    const files = event.dataTransfer.files;
    handleFileSelect(files);
});

function handleFileSelect(files) {
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.type === 'application/pdf') {
            renderPDF(file);
        } else {
            alert('File ' + file.name + ' is not a PDF.');
        }
    }
}


// fileInput.addEventListener('change', function() {
//     const file = this.files[0];
//     if (file && file.type === 'application/pdf') {
//         fileNameInput.value = file.name;
//         dragFileName.textContent=file.name;
//         renderPDF(file);
//     } else {
//         alert('Please select a PDF file.');
//         this.value = ''; 
//         fileNameInput.value = ''; 
//     }
// });
//pdf rendering using pdf.js


// function renderPDF(file) {
//     const fileReader = new FileReader();
//     fileReader.onload = function () {
//         const pdfData = new Uint8Array(this.result);
//         pdfjsLib.getDocument({ data: pdfData }).promise.then(pdf => {
//             pdf.getPage(1).then(page => {
//                 const canvas = document.createElement('canvas');
//                 const context = canvas.getContext('2d');
//                 const scale = 0.3;
//                 const viewport = page.getViewport({ scale});
//                 canvas.height = viewport.height;
//                 canvas.width = viewport.width;
//                 const renderContext = {
//                     canvasContext: context,
//                     viewport: viewport
//                 };

//                 page.render(renderContext).promise.then(() => {
//                     pdfViewer.innerHTML = ''; 
//                     pdfViewer.appendChild(canvas);
//                 });
//             });
//         }).catch(error => {
//             console.error('Error rendering PDF:', error);
//         });
//     };
   
//     fileReader.readAsArrayBuffer(file);

// }

function renderPDF(file) {
    const fileReader = new FileReader();
    fileReader.onload = function () {
        const pdfData = new Uint8Array(this.result);
        pdfjsLib.getDocument({ data: pdfData }).promise.then(pdf => {
            pdf.getPage(1).then(page => {
                const canvas = document.createElement('canvas');
                const context = canvas.getContext('2d');
                const scale = 0.2;
                const viewport = page.getViewport({ scale });
                canvas.height = viewport.height;
                canvas.width = viewport.width;
                const renderContext = {
                    canvasContext: context,
                    viewport: viewport
                };

                page.render(renderContext).promise.then(() => {
                    //pdfViewer.innerHTML = ''; 
                    //pdfViewer.appendChild(canvas);
                    const container = document.createElement('div');
                    container.className = 'pdf-container col-md-6';
                    
                    container.appendChild(canvas);
                    pdfViewer.appendChild(container);
                });
            });
        }).catch(error => {
            console.error('Error rendering PDF:', error);
        });
    };
   
    fileReader.readAsArrayBuffer(file);
}
function validatePdf(){
     
    if(fileInput =='' && fileNameInput==''){
        alert("hai");
        console.log("validate");

    }

}

//validation for add recipients starts

const nameInput = document.getElementById('nameInput');
const emailInput = document.getElementById('emailInput');
const statusSelect = document.getElementById('statusSelect');
const methodSelect = document.getElementById('methodSelect');
const addButton = document.getElementById('addButton');
const nameError = document.getElementById('nameError');
const emailError = document.getElementById('emailError');
const statusError = document.getElementById('statusError');
const methodError = document.getElementById('methodError');

addButton.addEventListener('click', function() {
    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const status = statusSelect.value.trim();
    const method = methodSelect.value.trim();
    console.log("add button clicked");
    nameError.textContent = '';
    emailError.textContent = '';
    statusError.textContent = '';
    methodError.textContent = '';

    let hasError = false;

    if (name === '') {
        nameError.textContent = 'Name is required';
        hasError = true;
    }

    if (email === '') {
        emailError.textContent = 'Email is required';
        hasError = true;
    } else if (!validateEmail(email)) {
        emailError.textContent = 'Invalid email format';
        hasError = true;
    }

    if (status === '') {
        statusError.textContent = 'Email Option is required';
        hasError = true;
    }

    if (method === '') {
        methodError.textContent = 'Phone/Email is required';
        hasError = true;
    }

    if (!hasError) {
        console.log('Form submitted successfully.');
    }

   

    const newRow = document.createElement('tr');
    newRow.innerHTML = `
        <td>
            <div class="d-flex align-items-center user gap-2">
                <h4>${name.charAt(0).toUpperCase()}</h4>
                <p>${name}</p>
            </div>
        </td>
        <td class="text-lowercase">${email}</td>
        <td>${status}</td>
        <td>
            <span><img src="./img/email.svg" alt="email" class="ep-icon"> ${method}</span>
        </td>
        <td>
            <button type="button" class="btn btn-outline btn-sm custom" data-bs-toggle="modal"
                data-bs-target="#customize">
                <i class="fa-solid fa-gear"></i> Customize
            </button>
        </td>
    `;
    
    const tableBody = document.getElementById('userTable').getElementsByTagName('tbody')[0];
    tableBody.appendChild(newRow);




});

//email regex function
function validateEmail(email) { 
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

//validation for add recipients end


//more setting validation starts

const daysToCompleteInput = document.getElementById('daysToComplete');
const validUntilInput = document.getElementById('validUntil');
const daysError = document.getElementById('daysError');
const validError = document.getElementById('validError');

daysToCompleteInput.addEventListener('input', validateDaysInput);
validUntilInput.addEventListener('input', validateValidUntilInput);

function validateDaysInput(event) {
    const input = event.target;
    const inputValue = input.value.trim();
    const errorElement = daysError;
    const pattern = /^\d+$/;
    if (!pattern.test(inputValue)) {
        errorElement.textContent = 'Please enter a valid number of days (e.g 10 or 20)';
        input.classList.add('is-invalid');
    } else {
        errorElement.textContent = '';
        input.classList.remove('is-invalid');
    }
}

function validateValidUntilInput(event) {
    const input = event.target;
    const inputValue = input.value;
    const errorElement = input.id === 'daysToComplete' ? daysError : validError;

    if (!/^\d{4}-\d{2}-\d{2}$/.test(inputValue)) {
        errorElement.textContent = 'Invalid date format (YYYY-MM-DD)';
        input.classList.add('is-invalid');
    } else {
        errorElement.textContent = '';
        input.classList.remove('is-invalid');
    }
}

//more settings validation ends


//continue button  validation

function onSubmit(){
    if (fileInput.value === '' && fileNameInput.value === '') {
        alert("Please choose the PDF file.");
    }
    if(emailInput.value== '' && nameInput.value==''){
        alert("Choose atleast one recipient.")
    }
}
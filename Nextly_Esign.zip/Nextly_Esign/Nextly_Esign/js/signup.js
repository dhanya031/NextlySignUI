function togglePasswordVisibility(inputId, iconId) {
    const inputElement = document.getElementById(inputId);
    const iconElement = document.getElementById(iconId);
    if (inputElement.type === "password") {
        inputElement.type = "text";
        iconElement.classList.remove("fa-eye");
        iconElement.classList.add("fa-eye-slash");
    } else {
        inputElement.type = "password";
        iconElement.classList.remove("fa-eye-slash");
        iconElement.classList.add("fa-eye");
    }
}
function validateName() {
    var nameInput = document.getElementById('name');
    var nameError = document.getElementById('nameError');
    nameError.textContent = '';
    if (nameInput.value.trim() == '') {
        nameError.textContent = 'Name is required';
    }
}
function emailValidation(){
    var email = document.getElementById('email').value;
    var emailError = document.getElementById('emailError');
    emailError.textContent = '';
    if (email=='') {
        emailError.textContent = 'Email is required';
     
    } else if (!validateEmail(email)) {
        emailError.textContent = 'Invalid email';
      
    }
}

function passwordValidation() {
    var password = document.getElementById('passwordInput').value;
    var passwordError = document.getElementById('passwordError');
    passwordError.textContent = '';
    if (password=='') {
        passwordError.textContent = 'Password is required';

    }
}
function confirmPasswordValidation(){
    var password = document.getElementById('passwordInput').value.trim();
    var confirmPassword = document.getElementById('confirmPasswordInput').value.trim();
    var confirmPasswordError = document.getElementById('confirmPasswordError');
    confirmPasswordError.textContent = '';
    if (confirmPassword=='') {
        confirmPasswordError.textContent = 'Confirm Password is required';
    } else if (confirmPassword && password !== confirmPassword) {
        confirmPasswordError.textContent = 'Passwords do not match';
    }

}

function validateEmail(email) {
    var re =/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}


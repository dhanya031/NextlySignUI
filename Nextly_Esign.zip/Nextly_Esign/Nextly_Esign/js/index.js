function togglePasswordVisibility(iconId, inputId) {
    const inputElement = document.getElementById(inputId);
    const iconElement = document.getElementById(iconId);
    
    if (inputElement.type === "password") {
        inputElement.type = "text";
        iconElement.classList.remove("fa-eye");
        iconElement.classList.add("fa-eye-slash");
    } else {
        inputElement.type = "password";
        iconElement.classList.remove("fa-eye-slash");
        iconElement.classList.add("fa-eye");
    }
}


function validateForm(){
    var email = document.getElementById('emailInput').value;
    var password = document.getElementById('passwordInput').value;
    emailError.textContent = '';
    passwordError.textContent = '';
    if (email =='' || password ==''){
        emailError.textContent = 'Required field';
        passwordError.textContent = 'Required field';

    }
}


function emailValidation(){
    var email = document.getElementById('emailInput').value;
    var emailError = document.getElementById('emailError');
    emailError.textContent = '';
    if (email=='') {
        emailError.textContent = 'Email is required';
     
    } else if (!validateEmail(email)) {
        emailError.textContent = 'Invalid email';
      
    }
}

function passwordValidation() {
    var password = document.getElementById('passwordInput').value;
    var passwordError = document.getElementById('passwordError');
    passwordError.textContent = '';
    if (password=='') {
        passwordError.textContent = 'Password is required';

    }
}

// Regular expression for email validation
function validateEmail(email) {
    var re =/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}
